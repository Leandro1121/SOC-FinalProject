## Contributing

Contributions are very welcome!
If you have any questions, bug reports, ideas or if you want to
give some kind of feedback, feel free to open a [new issue](https://github.com/stnolting/neorv32/issues/new/choose)
or start a new [discussion](https://github.com/stnolting/neorv32/discussions).
Also look out for issues and pull requests labeled with
[![help-wanted](https://img.shields.io/badge/-help%20wanted-brightgreen)](https://github.com/stnolting/neorv32/labels/help%20wanted) and
[![good-first-issue](https://img.shields.io/badge/-good%20first%20issue-purple)](https://github.com/stnolting/neorv32/labels/good%20first%20issue);
the latter one might be a good starting point for newcomers and beginners.

Please make sure your changes are clear, well-documented, and focused.
For larger/breaking changes, please discuss them first via an issue.

### Code of Conduct

Note that we have a [Code of Conduct](https://github.com/stnolting/neorv32/blob/main/CODE_OF_CONDUCT.md).
By participating and contributing to this project, you agree to uphold our Code of Conduct.

### Contributing Code

Here is a simple guide line if you'd like to contribute code modifications to this project:

1. [Fork](https://github.com/stnolting/neorv32/fork) this repository and clone the fork: `git clone https://github.com/stnolting/neorv32.git`
2. In your local copy, create a feature branch: `git checkout -b awesome_new_feature_branch`
3. Create a new _remote_ for the upstream repo: `git remote add upstream https://github.com/stnolting/neorv32`
4. Commit your modifications: `git commit -m "Awesome new feature!"`
5. Push to the branch: `git push origin awesome_new_feature_branch`
6. Create a new [pull request](https://github.com/stnolting/neorv32/pulls); please make sure that your feature branch is up-to-date
with the project's `main` branch; we will review your request as soon as possible.
7. If you like, discuss / show-case your work on the project's [discussion board](https://github.com/stnolting/neorv32/discussions).

### License of Contributions

By submitting a contribution to this project (including but not limited to pull requests, patches, documentation, or other materials),
you agree that:

- You are the original author of the contribution, or you have the right to submit it under the terms below.
- You grant this project a perpetual, worldwide, non-exclusive, royalty-free license to use, modify, distribute, and sublicense your contribution.
- Your contribution will be licensed under the same [license](LICENSE) as the project.

If you do not agree to these terms, please do not submit a contribution.
